#include <stdio.h>


void sort(int A[]){

    int i,j,temp,n;
    n=0;
    while(A[n]!='\0'){
        n++;
    }
    
    for(i=0; i<n; i++){
        for(int j=0; j<5-i; j++){
            if(A[j] > A[j+1]){
                temp = A[j];
                A[j] = A[j+1];
                A[j+1] = temp;
            }
        }
    }
}

void main(){
 
    int B[6]={10,-8,-20,-19,17,0};
    sort(B);
    int a=0;
	while(B[a]<=0){
		a++;
	}
	int x=0;
	while(a<6){
		x=B[a++]+x;
	}
	printf("%d\n",x);

    
}