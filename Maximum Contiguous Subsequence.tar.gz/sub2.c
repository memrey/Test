#include <stdio.h>

int max(int A[],int B[]){

	int j;
	if(A[j]>B[j]){
		return A[j];
	}
	else{
		return B[j];
	}
}

int optimal_index(int A[]){

	int m,n;
	int b=0;
    while(A[b]!='\0'){
        b++;
    }
    int opt=A[0];
	for(m=1;m<b;m++){
		if(A[m]>opt){
			opt=A[m];
		}
	}
	return (m+1);

	
}

void main(){

	int A[100]={-6,2,-4,1,3,-1,5,-1};
	int i,a,d=0;
	int n=0;
    while(A[n]!='\0'){
        n++;
    }
	int S[n];
	for(i=0;i<n;i++){
		if(i==0){

			S[i]=A[i];
		}
		else {

			S[i]=max((S[i-1]+A[i]),A[i]);
		}
	}
	int x=optimal_index(S);
	a=0;
	while(S[a]>0 && a<=x){
		d=S[a++]+d;
	}

	printf("%d\n",d);
	
}